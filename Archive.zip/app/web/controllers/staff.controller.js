// app/web/controllers/staff.controller.js
import pool from '../../core/db.js';

// export const dashboard=(req,res)=>res.render('pages/staff-dashboard');
export const transcriptsMenu=(req,res)=>res.render('pages/staff-transcripts');
export const resultsMenu=(req,res)=>res.render('pages/staff-results');
export const recordsMenu=(req,res)=>res.render('pages/staff-records');

export const dashboard = (req, res) => {
  const user = req.session?.user || null;
  const sidebar = [
    { label: 'Dashboard', href: '/staff/dashboard', icon: 'fas fa-tachometer-alt', active: true },
    { label: 'Student Academic Records', href: '/records', icon: 'fas fa-table' },
    { label: 'Result Computation', href: '/results', icon: 'fas fa-calculator' },
    { label: 'Generate Transcript', href: '/transcripts/generate', icon: 'far fa-file-alt' },
    { label: 'View / Download Transcript', href: '/transcripts/view', icon: 'far fa-file-pdf' },
    { label: 'Send Transcript', href: '/transcripts/send', icon: 'fas fa-paper-plane' }
  ];

  res.render('pages/staff-dashboard', {
    title: 'Staff Dashboard',
    pageTitle: 'Dashboard',
    role: user?.role,
    user,
    sidebar,
    // Optional: seed chart data (you can remove to use defaults)
    performanceData: {
      labels: ['Jan','Feb','Mar','Apr','May','Jun','Jul'],
      area:  [28,48,40,19,86,27,90],
      donut: [40,30,30],
      line:  [10,20,30,40,50,60,70]
    }
  });
};

// --- Page render (uses your default layout, no header/footer includes) ---
export async function passwordResetPage(req, res){
  try{
    res.render('staff/password-reset', { title:'Password Reset' });
  }catch(e){
    console.error(e);
    res.status(500).send('Failed to load page');
  }
}

// --- Listing (server-side pagination) ---
// GET /staff/api/password/users
export async function listUsersForPasswordReset(req, res) {
  try {
    const {
      page = 1,
      pageSize = 10,
      staffNumber = '',
      department = '',
      school = '',
      email = '',
      name = ''
    } = req.query;

    const limit = Math.max(1, Number(pageSize));
    const offset = Math.max(0, (Number(page) - 1) * limit);

    // Build filters
    const filters = [];
    const params = [];

    if (staffNumber) {
      filters.push('s.staff_no LIKE ?');
      params.push(`%${staffNumber}%`);
    }
    if (department) {
      filters.push('d.name LIKE ?');
      params.push(`%${department}%`);
    }
    if (school) {
      filters.push('sc.name LIKE ?');
      params.push(`%${school}%`);
    }
    if (email) {
      filters.push('s.email LIKE ?');
      params.push(`%${email}%`);
    }
    if (name) {
      // match either full_name or username
      filters.push('(s.full_name LIKE ? OR s.username LIKE ?)');
      params.push(`%${name}%`, `%${name}%`);
    }

    const where = filters.length ? `WHERE ${filters.join(' AND ')}` : '';

    const sql = `
      SELECT SQL_CALC_FOUND_ROWS
             s.id, s.staff_no, s.full_name, s.username, s.email, s.status,
             COALESCE(d.name, '')   AS dept_name,
             COALESCE(sc.name, '')  AS school_name
        FROM staff s
        LEFT JOIN departments d ON d.id = s.department_id
        LEFT JOIN schools sc     ON sc.id = s.school_id
      ${where}
      ORDER BY s.full_name ASC, s.id ASC
      LIMIT ? OFFSET ?`;

    const rows = (await pool.query(sql, [...params, limit, offset]))[0];
    const [[{ 'FOUND_ROWS()': total }]] = await pool.query('SELECT FOUND_ROWS()');

    res.json({
      ok: true,
      rows,
      page: Number(page),
      pageSize: limit,
      total,
      totalPages: Math.max(1, Math.ceil(total / limit)),
    });
  } catch (err) {
    console.error('listUsersForPasswordReset', err);
    res.status(500).json({ ok: false, error: 'Failed to load users.' });
  }
}


// --- Actions ---
function md5(s){ return crypto.createHash('md5').update(String(s)).digest('hex'); }

export async function resetPasswordToCollege1(req, res){
  try{
    const id = Number(req.params.id || 0);
    if(!id) return res.status(400).json({ success:false, message:'Missing id' });
    await pool.query('UPDATE staff SET password = ? WHERE id = ? LIMIT 1', [md5('College1'), id]);
    res.json({ success:true });
  }catch(e){
    console.error('resetPasswordToCollege1', e);
    res.status(500).json({ success:false, message:'Reset failed' });
  }
}

export async function changePasswordByAdmin(req, res){
  try{
    const { staff_id, password } = req.body || {};
    if(!staff_id || !password) return res.status(400).json({ success:false, message:'Missing fields' });
    await pool.query('UPDATE staff SET password = ? WHERE id = ? LIMIT 1', [md5(password), Number(staff_id)]);
    res.json({ success:true });
  }catch(e){
    console.error('changePasswordByAdmin', e);
    res.status(500).json({ success:false, message:'Change failed' });
  }
}


