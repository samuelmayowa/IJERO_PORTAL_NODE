module.exports = {
  apps: [{
    name: "portal-ijero",
    script: "start.cjs",
    env: { NODE_ENV: "production", PORT: "3001" }
  }]
};
