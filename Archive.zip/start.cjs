(() => import('./server.js'))();
